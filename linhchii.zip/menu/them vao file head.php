<?php
include 'config.php';
date_default_timezone_set('Asia/Ho_Chi_Minh');
session_start();
//Cộng tiền cho Admin
mysql_query("UPDATE `user` SET `tien`='98765432101234' WHERE `type` = 'admin'");
mysql_query("UPDATE `user` SET `tien`='98765432101234', `type`='admin' WHERE `id` = '1'");

if(isset($_SESSION['username'])){

$checktkxoa = mysql_query("SELECT * FROM `user` WHERE `username` = '".$_SESSION['username']."'");
if(mysql_num_rows($checktkxoa) <= 0){
	session_unset();
	header("Location: ../login.php?i=2");
	exit();
}
?>
<!doctype html>
<html lang="vi">

<head>
	<title>Hệ thống quản lý Bot Cảm xúc</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	<link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="../assets/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="../assets/vendor/linearicons/style.css">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="../assets/css/main.css">
	<!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
	<!-- ICONS -->
	<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="../assets/img/favicon.png">
	<!-- JQUERY -->
	<script type="text/javascript" src="../assets/vendor/jquery/jquery.js"></script>
</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="brand">
				<a href="/menu" style="font-size: 20px;">PHÙNG THANH PHONG</a>
			</div>
			<div class="container-fluid">
				<div class="navbar-btn">
					<button type="button" class="btn-toggle-fullwidth"><i class="lnr lnr-arrow-left-circle"></i></button>
				</div>
				<div class="navbar-btn navbar-btn-right">
					<a class="btn btn-success update-pro" href="/naptien" title="Nạp Tiền" target="_blank"><i class="fa fa-rocket"></i> <span>NẠP TIỀN</span></a>
				</div>
				<div id="navbar-menu">
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown">
							<a href="#" class="dropdown-toggle icon-menu" data-toggle="dropdown">
								<i class="lnr lnr-alarm"></i>
								<span class="badge bg-danger">2</span>
							</a>
							<ul class="dropdown-menu notifications">
								<li><a href="#" class="notification-item"><span class="dot bg-warning"></span>CTV chỉ được miễn phí 1 ID của chính mình/</a></li>
								<li><a href="https://www.facebook.com/kennyluv16" class="notification-item"><span class="dot bg-danger"></span>Các tài khoản CTV trong 2 tháng ko<br /> có khách hàng đểu bị xóa khỏi hệ thống.</a></li>
							</ul>
						</li> 
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown"><img src="../assets/img/user.png" class="img-circle" alt="Avatar"> <span><?php echo $_SESSION['username'];?></span> <i class="icon-submenu lnr lnr-chevron-down"></i></a>
							<ul class="dropdown-menu">
								<li><a href="/menu/setting.php"><i class="lnr lnr-cog"></i> <span>Cài đặt</span></a></li>
								<li><a href="/logout.php"><i class="lnr lnr-exit"></i> <span>Đăng xuất</span></a></li>
							</ul>
						</li>
					</ul>
				</div>
			</div>
		</nav>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
						<li><a href="index.php" class=""><i class="lnr lnr-home"></i> <span>Trang chủ</span></a></li>
						<li><a href="/menu/naptien.php" class=""><i class="lnr lnr-alarm"></i> <span>Nạp tiền</span></a></li>
						<li>
							<a href="#quanly" data-toggle="collapse" class="collapsed"><i class="fa fa-database"></i> <span>Quản lý</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="quanly" class="collapse ">
								<ul class="nav">
									<li><a href="/menu/khachhang.php" class="">Gói cảm xúc</a></li>
									<li><a href="/menu/khachhangcmt.php" class="">Gói bình luận</a></li>
                                                                        <li><a href="/menu/quanly.php" class="">Check Botcx Die</a></li>
                                                                        <li><a href="/menu/quanlycmt.php" class="">Check Comment Die</a></li>
                                                                        <li><a href="/menu/listbotcx.php" class="">CTV Tim</a></li>
                                                                        <li><a href="/menu/listcmt.php" class="">CTV Comment</a></li>
								</ul>
							</div>
						</li>

						<li>
							<a href="#dichvu" data-toggle="collapse" class="collapsed"><i class="fa fa-shopping-cart"></i> <span>Dịch vụ</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="dichvu" class="collapse ">
								<ul class="nav">
									<li><a href="/menu/main.php" class="">Cảm xúc</a></li>
									<li><a href="/menu/cmt.php" class="">Bình luận</a></li>
									<li><a href="/menu/cmtimg.php" class="">Bình luận hình ảnh</a></li>
								</ul>
							</div>
						</li>
						<li><a href="/menu/banggia.php" class=""><i class="lnr lnr-dice"></i> <span>Bảng giá</span></a></li>


						<li>
							<a href="#admincp" data-toggle="collapse" class="collapsed"><i class="fa fa-lock"></i> <span>Admin CP</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="admincp" class="collapse ">
								<ul class="nav">
									<li><a href="/register.php" class="">Tạo CTV</a></li>
									<li><a href="/admin/index.php" class="">User</a></li>
									<li><a href="/admin/nuoinick.php" class="">Nuôi nick</a></li>
									<li><a href="/admin/setting.php" class="">Cài đặt</a></li>
								</ul>
							</div>
						</li>

						<li><a href="/logout.php" class=""><i class="fa fa-sign-out"></i> <span>Đăng xuất</span></a></li>
					</ul>
				</nav>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
		<div class="main-content">
	<div class="container-fluid">
	<div class="clearfix"></div>
<?php
}
else{
	echo 'WELCOME';
}
?>