    <link href="http://viplike.shally.net/lenlike/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="http://viplike.shally.net/lenlike/vendors/bootstrap/dist/css/bootstrap.css" rel="stylesheet"/>
    <link href="http://viplike.shally.net/lenlike/vendors/bootstrap/dist/css/main.css" rel="stylesheet"/>
    <link href="http://viplike.shally.net/lenlike/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet"/>
    <link href="http://viplike.shally.net/lenlike/vendors/line-awesome/css/line-awesome.min.css" rel="stylesheet"/>
    <link href="http://viplike.shally.net/lenlike/vendors/themify-icons/css/themify-icons.css" rel="stylesheet"/>
    <link href="http://viplike.shally.net/lenlike/vendors/animate.css/animate.min.css" rel="stylesheet"/>
    <link href="http://viplike.shally.net/lenlike/vendors/toastr/toastr.min.css" rel="stylesheet"/>
    <script src="https://apis.google.com/js/platform.js" async defer>
    {lang: 'vi'}
</script>
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="http://viplike.shally.net/lenlike/assets/css/main.css" rel="stylesheet"/>
  </head>
  <body>  <div class="container" role="main">
      <div class="row">
 <div class="col-sm-12 blog-main content">
  <div class="panel with-nav-tabs panel-primary">
      <div class="panel-heading">
      <ul class="nav nav-tabs">
    </ul>
    </div>
 <div class="panel-body">
      <div class="tab-content">
        <div class="tab-pane fade in active" id="faq">
  <table class="table table-bordered" id="table"><b>
      <table class="table">
        <thead>
          <tr>
            <th>
              username
            </th>
            <th>
              FB ID
            </th>
            <th>
              Họ tên
            </th>
            <th>
              Ngày Đăng Kí
            </th>
            <th>
              Hạn Sử Dụng
            </th>
          </tr>
        </thead>
        <tbody>
<?php
require '../incf/config.php';
  $sqr = mysql_query("SELECT * FROM `khachhangcmt`");
          while ($tri = mysql_fetch_array($sqr)) {
$check = $tri['timemua'] - time();
$level = 86400 * 2;
if ($check < $level) {
$saphethan = '<font color="red">Sap Het Han </font>';
}else {
$saphethan = date("H:i:s d-m-Y", $tri['timemua']);
}
echo '<center>
            <td>
            '. $tri['useradd'].'
            </d>
            <td>
              '. $tri['user_id'].'
            </td>
            <td>
              '. $tri['name'].'
            </td>
            <td>
              '. date("H:i:s d-m-Y", $tri['time']).'
            </td>
            <td>
              '.$saphethan.'
            </td>
          </tr>
        </tbody>
';
}
?>
</center></b></table></div></div></div></div></div>
    <script src="http://viplike.shally.net/lenlike/vendors/jquery/dist/jquery.min.js" type="text/javascript"></script>
    <script src="http://viplike.shally.net/lenlike/vendors/popper.js/dist/umd/popper.min.js" type="text/javascript"></script>
    <script src="http://viplike.shally.net/lenlike/vendors/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="http://viplike.shally.net/lenlike/vendors/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>
    <script src="http://viplike.shally.net/lenlike/vendors/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <script src="http://viplike.shally.net/lenlike/vendors/jquery-idletimer/dist/idle-timer.min.js" type="text/javascript"></script>
    <script src="http://viplike.shally.net/lenlike/vendors/toastr/toastr.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL PLUGINS-->
    <script src="http://viplike.shally.net/lenlike/vendors/chart.js/dist/Chart.min.js" type="text/javascript"></script>
    <script src="http://viplike.shally.net/lenlike/vendors/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js" type="text/javascript"></script>
    <script src="http://viplike.shally.net/lenlike/vendors/jquery-sparkline/dist/jquery.sparkline.min.js" type="text/javascript"></script>
    <script src="http://viplike.shally.net/lenlike/vendors/clipboard/dist/clipboard.min.js" type="text/javascript"></script>
    <script src="http://viplike.shally.net/lenlike/vendors/alertifyjs/dist/js/alertify.js" type="text/javascript"></script>

    <!-- CORE SCRIPTS-->
    <script src="http://viplike.shally.net/lenlike/assets/js/app.js" type="text/javascript"></script>
    <!-- PAGE LEVEL SCRIPTS--> 
</body> 
</html>

