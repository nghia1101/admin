﻿<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>[Truy Cập Bị Cấm]</title>
	<style type="text/css">
		html,body{border:0px;padding:0px;margin:0px;}
		body{background:#000;color:#4D7885;font-size:12px;font-family:arial;}
		#MID_TEXT{background:#000;position:absolute;top:20%;left:50%;margin-left:-320px;width:600px;border-top:solid #112f39 1px;border-bottom:solid #112f39 1px;padding-top:5px;padding-bottom:5px;padding-left:10px;padding-right:10px;word-wrap:break-word;}
		#MID_TEXT h3{font-size:14px;text-align:center;}
		#MID_TEXT i{color:#FFC2C2;}
		.right_txt {text-align:right;}
		</style>
</head>
<body>
	<div id="MID_TEXT">
	<h3>Cảnh báo</h3>
	Bạn không thể truy cập vào khu vực này vì 1 trong những lý do sau:<br>
	[+] Trang hoặc dữ liệu bạn truy cập không tồn tại hoặc bạn không được phép truy cập.<br>
	[+] Yêu cầu không được chấp nhận hoặc không đúng với quy định.<br>
	[+] Hệ thống phát hiện dữ liệu bất thường.<br>
	[+] Yêu cầu xác thực Proxy.<br>
	[+] Đã chuyển.<br>
	[+] Bạn đã bị chặn.<br>
	[+] Hệ thống hoạt động không ổn định hoặc đang bảo trì.<br>
	<i>Hệ thống sẽ tự động chặn IP của bạn trong 1 khoảng thời gian nếu phát hiện hành vi phá hoại !</i>
	<br> <br> 
	<h3>Warning</h3>
	You cannot access this area, please check the following reasons:<br>
	[+] Page/Data you try to access does not exist or you are not allowed to access.<br>
	[+] Request is not approved or not comply with regulations.<br>
	[+] System detects abnormal request.<br>
	[+] Proxy Authentication required.<br>
	[+] Moved.<br>
	[+] You are blocked.<br>
	[+] Operating system unstable or maintenance.<br>
	<i>The system will automatically block your IP in a specified time if detected any acts of vandalism !</i>
	<br> <br>
	<p class="right_txt">BMN2312</p>
	</div>
</body></html>
