<?php
include '../incf/head.php';
require '../incf/config.php';
include '../incf/func.php';
if(isset($_SESSION['username'])){
  if(isset($_GET['thongbao'])){
  settype($_GET['thongbao'], 'int');
  if($_GET['thongbao'] == 3){
    echo '<script>alert("Xóa thành công!");</script>';
  }
}
?>
<div class="col-md-12">
  <div class="panel">
    <div class="panel-heading">
    <div class="panel-title">
      <div class="left">Quản lý khách gói BOT CX</div>
      <div class="right">
       <button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
    <button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
      </div>
    </div>
    </div>
    <div class="panel-body">
    <form method="post" action="/post/edit.php">
      <table class="table">
        <thead>
          <tr>
            <th>
              <input class="checkitem" type="checkbox" id="check_all" />
            </th>
             <th>
              FB ID
            </th>
            <th>
              Họ tên
            </th>
            <th>
              Ngày Đăng Kí
            </th>
            <th>
              Hạn Sử Dụng
            </th>
<th>
Hành Động
</th>
          </tr>
        </thead>
        <tbody>
        <?php 

if($_SESSION['type'] == 'admin'){
  $sokhachhang = mysql_query("SELECT * FROM `khachhang` ");
}
else{
 $sokhachhang = mysql_query("SELECT * FROM `khachhang` WHERE useradd = '".$_SESSION['username']."'");
}

$tongkh = mysql_num_rows($sokhachhang);
$sotrang = ceil($tongkh / 50);

if(isset($_GET['trang'])){
  settype($_GET['trang'], 'int');
  if($_GET['trang'] > $sotrang){
    $trang = $sotrang -1;
  }
  if($_GET['trang'] <= 0){
    $trang = 1;
  }
  else{
    $trang = $_GET['trang'];
  }
  
}
else{
          $trang = 1;
}
$from = ($trang - 1) * 50;
if($_SESSION['type'] == 'admin'){
$sqr = mysql_query("SELECT * FROM `khachhang` LIMIT ".$from.",50");
}
else{
  $sqr = mysql_query("SELECT * FROM `khachhang` WHERE useradd = '".$_SESSION['username']."' LIMIT ".$from.",50");
}
       
          while ($tri = mysql_fetch_array($sqr)) {
$check = $tri['timemua'] - time();
$level = 86400 * 2;
if ($check < $level) {
$saphethan = '<font color="red">Sap Het Han </font>';
}else {
$saphethan = date("H:i:s d-m-Y", $tri['timemua']);
}
echo '<center>
            <td>
           
              <input class="checkitem" type="checkbox" name="id[]" value=" '. $tri['id'].'" />
          
            </td>
            <td>
              '. $tri['user_id'].'
            </td>
            <td>
              '. $tri['name'].'
            </td>
            <td>
              '. date("H:i:s d-m-Y", $tri['time']).'
            </td>
            <td>
              '.$saphethan.'
            </td>
 <td>
              <a href="/post/edit.php?sua='.$tri['id'].'"> <span class="label label-info">Sửa</span></a>
            </td>
          </tr>
        </tbody>
';
}
?>
      </table>

      <button class="btn btn-danger" type="submit" value="delete_all" name="submit"><i class="lnr lnr-trash"></i> <span> XÓA</span></button>
      </form>
<!--       <div action="" style="text-align: center; position: relative; top: 1px;" method="get"> Trang <input style="width: 36px;height: 36px; display: inline;" type="number" name="trang" value=""></div> -->
      <?php 
      $trangtruoc = $trang - 1;
      $trangsau = $trang + 1;
      ?>
<ul class="pager">
  <li class="previous"><a href="?trang=<?php if($trangtruoc <= 0) {echo 1;}else{echo $trangtruoc;}?>">Trước</a></li>
<!--   
 -->  <li class="next"><a href="?trang=<?php if($trangsau > $sotrang) {echo $sotrang;}else{echo $trangsau;}?>">Sau</a></li>
</ul>
    </div>
  </div>
</div>
<script type="text/javascript">
    $(function(){
        /* Check/bỏ chek hết tất cả các records */
        $(document).on('change','#check_all', function(ev){
            $('.checkitem').prop('checked', this.checked).trigger('change');
        });
        /* Check/bỏ chek từng records */
        $(document).on('change','.checkitem', function(ev){
            var _dem = 0;
            var _checked = 1;
            /* Duyệt tất cả các checkitem */
            $('.checkitem').each(function(){
                if($(this).is(':checked')){
                    _dem ++;
                }else{
                    _checked = 0;
                }
            });
            $('#check_all').prop('checked', _checked);
            if(_dem > 0){
                // Hiện nút xóa chọn
                $('button[name=submmit]').show();
            }else{
                // Ẩn nút xóa chọn
                $('button[name=submmit]').hide();
            }
        });
    });
</script>

<!-- <div class="col-md-12">
  <div class="panel">
  <div class="panel-heading">
      Chỉnh sửa
<div class="right">
    <button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
    <button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
</div> 
  </div>
  <div class="panel-body">
    
      <div class="form-group">
        <label>Họ và tên:</label>
          <input class="form-control" type="text" disabled>
      </div>

      <div class="form-group">
        <label>Thêm tháng:</label>
        <input type="text" class="form-control" placeholder="Tháng thêm...">
      </div>

      <div class="form-group">
        <label>Cảm xúc:</label>
        <select class="form-control">
          <option>LIKE</option>
          <option>LOVE</option>
          <option>HAHA</option>
          <option>ANGRY</option>
          <option>WOW</option>
        </select>
      </div>
 <button type="button" class="btn btn-primary btn-block">Cập nhật</button>
  </div>
  </div>

</div> -->

<?php
include '../incf/foot.php';
}
?>
