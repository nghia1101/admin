<?php
session_start();
if(isset($_SESSION['username'])){
	include '../incf/func.php';
	include '../incf/config.php';
	if(isset($_POST['id'])){
	$idxoa =  implode(',',$_POST['id']);
    settype($idxoa, 'int');
    $check = mysql_fetch_array(mysql_query("SELECT * FROM `khachhangcmtimg` WHERE id = '".$idxoa."' "));
      if($check['useradd'] = $_SESSION['username']){
          mysql_query ("DELETE FROM `khachhangcmtimg` WHERE `id` IN (".$idxoa.")");
          /*mysql_query("DELETE FROM khachhang WHERE id IN (".implode(',',$_POST['id']).")");
          */
          header("Location: /menu/khachhangcmtimg.php?thongbao=3");
      }
	}
	if(isset($_GET['sua'])){
		$id = $_GET['sua'];
		settype($id, 'int');
 $checkedit = mysql_fetch_array(mysql_query("SELECT * FROM `khachhangcmtimg` WHERE id = '".$id."' "));
        if($checkedit['useradd'] != $_SESSION['username']){
          if($_SESSION['type'] == 'admin'){
            echo '<script>alert("Người thêm '.$checkedit['useradd'].', cân nhắc trước khi sửa");</script>';
          }else{
          echo '<script>alert("Khách hàng này không do bạn quản lý, chúng tôi đã lưu bạn vào danh sách đen của hệ thống! Khi vi phạm quá 3 lần tài khoản của bạn sẽ bị xóa bởi hệ thống! Nếu bạn thấy do nhầm lẫn vui lòng liên hệ với Admin để được xóa khỏi danh sách đen.");</script><meta http-equiv="refresh" content="0">
';
          session_unset();
          exit();

          }

        }
	?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sửa thông tin người dùng</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<?php 
$info = thongtinkhachcmtimg($id);
?> 
<div class="container">
<div style="margin-top: 30px;"></div>
<div class="col-md-6">
  <div class="panel panel-default">
    <div class="panel-heading">Chỉnh sửa thông tin User</div>
    <div class="panel-body">
<form class="form-horizontal" method="POST" action="/post/updatecmtimg.php">
           <div class="form-group">
            <label class="col-sm-4 control-label">
              Name:  
            </label>
            <div class="col-sm-7">
           <input type="text" class="form-control" disabled value="<?php echo $info['name'];?>">
            </div>
          </div>
          <input type="hidden" class="form-control" name="fuckid" value="<?php echo $info['id'];?>">
          <div class="form-group">
            <label class="col-sm-4 control-label">
              Cookie * 
            </label>
            <div class="col-sm-7">
              <input type="text" class="form-control" value="<?php echo $info['cookie'];?>" name="cookie" placeholder="Dán Cookie vào đây...">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-4 control-label">
              Access_Token * 
            </label>
            <div class="col-sm-7">
              <input type="text" class="form-control" value="<?php echo $info['token'];?>" name="token" placeholder="Dán Token vào đây...">
            </div>
          </div>

          <div class="form-group">
            <label class="col-sm-4 control-label">
              Thời gian (tháng) * 
            </label>
            <div class="col-sm-7">
        <input type="number" class="form-control" name="thoigian" placeholder="Số tháng">
            </div>
            
          </div>
            <div class="form-group">
            <label class="col-sm-4 control-label">
              Bật/Tắt Comment * 
            </label>
            <div class="col-sm-7">
        <select class="form-control" name="battatcmt">
              <option value="1">BẬT</option>
              <option value="0">TẮT</option>
           </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-4 control-label">
              Nội dung comment * 
            </label>
            <div class="col-sm-7">
            <textarea name= "noidungcmt" class="form-control" rows="5" id="comment"><?php echo $info['noidungcmt'];?></textarea>
            </div>
          </div>

          <div class="form-group">
            <label class="col-sm-4 control-label">
              Link ảnh * 
            </label>
            <div class="col-sm-7">
            <textarea class="form-control" name="anh" rows="5" id="comment"><?php echo $info['image'];?></textarea>
            </div>
          </div>

          <div class="form-group text-center">
          <a href="/menu/khachhangcmtimg.php" class="btn btn-default">
              Quay lại
            </a>
            <input type="hidden" name="action" value="themkhachang">
            <button type="submit" class="btn btn-success">
              Cập nhật
            </button>
          </div>
</form>

    </div>
  </div>
  </div>
  <div class="col-md-6">
	<div class="panel panel-default">
	    <div class="panel-heading">Thông tin người dùng</div>
	    <div class="panel-body">
		<ul class="list-group">
		  <li class="list-group-item">Tên <span class="badge"><?php echo $info['name'];?></span></li>
		  <li class="list-group-item">ID FB <span class="badge"><?php echo $info['user_id'];?></span></li> 
		  <li class="list-group-item">Người thêm <span class="badge"><?php echo $info['useradd'];?></span></li> 
		  <?php
			switch ($info['battatcmt']) {
			    case '1':
			      $cx = 'BẬT';
			      break;
			    default:
			      $cx = 'TẮT';
			      break;
			  }
			  $songayh = $info['timemua'] - time();
		  ?>
		  <li class="list-group-item">TRẠNG THÁI <span class="badge"><?php echo $cx;?></span></li>
		  <li class="list-group-item">Còn lại <span class="badge"><?php echo ham_chuyen_doi($songayh);?></span></li>
		  <li class="list-group-item">TOKEN : <?php echo checklivetk($info['token']);?> Cookie: <?php echo checkliveck($info['cookie']);?></li>
		</ul>
    <img style="text-align: center;" src="<?php echo $info['image'];?>" width="400px">
	    </div>
    </div>

  </div>
</div>
</body>
</html>

	<?php
	}	
}else{
	echo 'WELCOME TO VIETNAM';
}

?>