<?php
session_start();
if(!$_SESSION['username']){
  echo '<meta http-equiv=refresh content="1; URL=https://thatimtudong.com/login.php">';
  exit();
}
if(isset($_SESSION['username'])){
    include '../incf/func.php';
    include '../incf/config.php';
    if(isset($_POST['id'])){
    $idxoa =  implode(',',$_POST['id']);
    settype($idxoa, 'int');
    $check = mysql_fetch_array(mysql_query("SELECT * FROM `khachhang` WHERE id = '".$idxoa."' "));
      if($check['useradd'] = $_SESSION['username']){
          mysql_query ("DELETE FROM `khachhang` WHERE `id` IN (".$idxoa.")");
          /*mysql_query("DELETE FROM khachhang WHERE id IN (".implode(',',$_POST['id']).")");
          */
          header("Location: /menu/khachhang.php?thongbao=3");
      }
    }
    if(isset($_GET['sua'])){
        $id = $_GET['sua'];
        settype($id, 'int');
        $checkedit = mysql_fetch_array(mysql_query("SELECT * FROM `khachhang` WHERE id = '".$id."' "));
        if($checkedit['useradd'] != $_SESSION['username']){
          if($_SESSION['type'] == 'admin'){
            echo '<script>alert("Người thêm '.$checkedit['useradd'].', cân nhắc trước khi sửa");</script>';
          }else{
          echo '<script>alert("Khách hàng này không do bạn quản lý, chúng tôi đã lưu bạn vào danh sách đen của hệ thống! Khi vi phạm quá 3 lần tài khoản của bạn sẽ bị xóa bởi hệ thống! Nếu bạn thấy do nhầm lẫn vui lòng liên hệ với Admin để được xóa khỏi danh sách đen.");</script><meta http-equiv="refresh" content="0">
';
          session_unset();
          exit();

          }

        }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sửa thông tin người dùng</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<?php 
$info = thongtinkhach($id);
?> 
<div class="container">
<div style="margin-top: 30px;"></div>
<div class="col-md-6">
  <div class="panel panel-default">
    <div class="panel-heading">Chỉnh sửa thông tin User</div>
    <div class="panel-body">
<form class="form-horizontal" method="POST" action="/post/update.php">
           <div class="form-group">
            <label class="col-sm-4 control-label">
              Name:  
            </label>
            <div class="col-sm-7">
           <input type="text" class="form-control" disabled value="<?php echo $info['name'];?>">
            </div>
          </div>
          <input type="hidden" class="form-control" name="fuckid" value="<?php echo $info['id'];?>">
          <div class="form-group">
            <label class="col-sm-4 control-label">
              Cookie * 
            </label>
            <div class="col-sm-7">
              <input type="text" class="form-control" value="<?php echo $info['cookie'];?>" name="cookie" placeholder="Dán Cookie vào đây...">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-4 control-label">
              Access_Token * 
            </label>
            <div class="col-sm-7">
              <input type="text" class="form-control" value="<?php echo $info['token'];?>" name="token" placeholder="Dán Token vào đây...">
            </div>
          </div>

          <div class="form-group">
            <label class="col-sm-4 control-label">
              Thời gian (tháng) * 
            </label>
            <div class="col-sm-7">
        <input type="number" class="form-control" name="thoigian" placeholder="Số tháng">
            </div>
            
          </div>
            <div class="form-group">
            <label class="col-sm-4 control-label">
              Hành động * 
            </label>
            <div class="col-sm-7">
        <select class="form-control" name="camxuc">
              <option value="like">LIKE</option>
              <option value="love">LOVE</option>
              <option value="haha">HAHA</option>
              <option value="sad">SAD</option>
              <option value="wow">WOW</option>
              <option value="angry">ANGRY</option>
           </select>
            </div>
          </div>
            <div class="form-group">
            <label class="col-sm-4 control-label">
              Loại Tương Tác * 
            </label>
            <div class="col-sm-7">
        <select class="form-control" name="loaituongtac">
              <option value="1"<?= $info['loaituongtac'] == 1 ? ' selected="selected"' : '' ?>>Bạn Bè</option>
              <option value="2"<?= $info['loaituongtac'] == 2 ? ' selected="selected"' : '' ?>>Bạn Bè, Nhóm, Fanpage</option>
           </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-4 control-label">
              Hoạt động từ (Nhập giờ)* 
            </label>
            <div class="col-sm-7">
        <input type="number" class="form-control" name="tghd1" placeholder="Từ" value="<?= $info['tghd1'] ?>">
            </div>
            
          </div>
          <div class="form-group">
            <label class="col-sm-4 control-label">
              Đến (Nhập giờ) * 
            </label>
            <div class="col-sm-7">
        <input type="number" class="form-control" name="tghd2" placeholder="Đến" value="<?= $info['tghd2'] ?>">
            </div>
            
          </div>
          <div class="form-group text-center">
            <input type="hidden" name="action" value="themkhachang">
            <a href="/menu/khachhang.php" class="btn btn-default">
              Quay lại
            </a>
            <button type="submit" class="btn btn-success">
              Thêm khách hàng
            </button>
          </div>
</form>

    </div>
  </div>
  </div>
  <div class="col-md-6">
    <div class="panel panel-default">
        <div class="panel-heading">Thông tin người dùng</div>
        <div class="panel-body">
        <ul class="list-group">
          <li class="list-group-item">Tên <span class="badge"><?php echo $info['name'];?></span></li>
          <li class="list-group-item">ID FB <span class="badge"><?php echo $info['user_id'];?></span></li> 
          <li class="list-group-item">Người thêm <span class="badge"><?php echo $info['useradd'];?></span></li> 
          <?php
            switch ($info['camxuc']) {
                case '1':
                  $cx = 'LIKE';
                  break;
                case '2':
                  $cx = 'LOVE';
                  break;
                case '3':
                  $cx = 'WOW';
                  break;
                case '4':
                  $cx = 'HAHA';
                  break;
                case '8':
                  $cx = 'ANGRY';
                  break;
                default:
                  $cx = 'LOVE';
                  break;
              }
              $songayh = $info['timemua'] - time();
          ?>
          <li class="list-group-item">Cảm xúc <span class="badge"><?php echo $cx;?></span></li>
          <li class="list-group-item">Còn lại <span class="badge"><?php echo ham_chuyen_doi($songayh);?></span></li>
          <li class="list-group-item">TOKEN : <?php echo checklivetk($info['token']);?> Cookie: <?php echo checkliveck($info['cookie']);?></li>
        </ul>
        </div>
    </div>

  </div>
</div>
</body>
</html>

    <?php
    }   
}else{
    echo 'WELCOME TO VIETNAM';
}

?>