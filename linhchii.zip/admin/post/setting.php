<?php
//CTV Post là xóa luôn

session_start();
if(isset($_SESSION['username']){
	if($_SESSION['type'] == 'admin'){

	}
}
?>