<!doctype html>
<html lang="vi" class="fullscreen-bg">

<head>
   <meta name="description" content="linhchii.cf - hệ thống auto thả tim, tự động thả tim, tự động hóa Facebook, tự động thả tim Facebook mới nhất, hệ thống tự động hóa Facebook. Tự động bình luận Facebook" />
    <meta name="keywords" content="tha tim, thả tim, tự động thả tim, bot cảm xúc,bot cảm xúc cookie,auto cảm xúc facebook,auto bot cảm xúc,auto cảm xúc trên facebook,hack cảm xúc,bot cảm xúc fb,auto cảm xúc fb,hack cảm xúc facebook "/>
    <meta name="revisit-after" content="1 days" />
    <meta name="robots" content="robots.txt"/>
    <title>Đăng ký</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="canonical" href="https://latezone.ga"/>
    <meta itemprop="name" content="linhchii.cf - Thả Tim Facebook">
    <meta itemprop="description" content="linhchii.cf - hệ thống auto thả tim, tự động thả tim, tự động hóa Facebook, tự động thả tim Facebook mới nhất, hệ thống tự động hóa Facebook. Tự động bình luận Facebook">
    <meta itemprop="image" content="ladding/img/huypham368.img">
    <!-- Facebook Meta -->
    <meta property="og:title" content="linhchii.cf - Tự động thả tim Facebook" /> 
    <meta property="og:locale" content="vi_VN" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://latezone.ga/register.php" /> 
    <meta property="og:image" content="ladding/img/huypham368.jpg" />
    <meta property="og:description" content="linhchii.cf - hệ thống auto thả tim, tự động thả tim, tự động hóa Facebook, tự động thả tim Facebook mới nhất, hệ thống tự động hóa Facebook. Tự động bình luận Facebook" /> 
    <meta property="og:site_name" content="linhchii.cf" />
    <meta property="fb:admins" content="100010624170277" />

    <!-- VENDOR CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/vendor/linearicons/style.css">
    <!-- MAIN CSS -->
    <link rel="stylesheet" href="assets/css/main.css">
    <!-- FOR DEMO PURPOSES ONLY. You should remove this in your project -->
    <link rel="stylesheet" href="assets/css/demo.css">
    <!-- GOOGLE FONTS -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
    <!-- ICONS -->
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
    <script type="text/javascript" src="assets/vendor/jquery/jquery.js"></script>
</head>

<body class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6" style="position: relative; top: 50px;">
        <div class="panel">
            <h3 class="panel-heading">Đăng ký tài khoản</h3>
            <div class="panel-body">
            <form class="form-auth-small" role="form" method="post">
                                <div class="form-group">
                                    <label for="signin-email" class="control-label sr-only">Tên đăng nhập</label>
                                    <input type="text" class="form-control" name="username" id="username"  required="" placeholder="Tên đăng nhập">
                                </div>
                                <div class="form-group">
                                    <label for="signin-password" class="control-label sr-only">Mật khẩu</label>
                                    <input type="password" class="form-control" name="pass" id="password" required=""  placeholder="mật khẩu">
                                </div>
                                <div class="form-group">
                                    <label for="signin-password" class="control-label sr-only">Nhập lại mật khẩu</label>
                                    <input type="password" class="form-control" name = "repass" id="repass" required="" placeholder="nhập lại mật khẩu">
                                </div>
                                <div class="form-group">
                                    <label for="signin-password" class="control-label sr-only">Điều khoản</label>
                                    <input type="checkbox" checked required=""> Bạn đồng ý với <a href="">điều khoản</a> của chúng tôi.
                                </div>
                                <input type="hidden" name="dangky">
                                <button type="submit" class="btn btn-primary btn-lg btn-block">Đăng ký</button>
                                <div class="text-center">
                                <br />
                                    <span><a href="/login.php">Bạn đã có tài khoản</a></span>
                                </div>
                            </form></div>
        </div>

    </div>
        <div class="col-md-3"></div>
<script type="text/javascript">
    $('form').submit(function(e){
        $(this).find('button').attr('disabled','');
        $(this).find('button').html('<i class="fa fa-spinner faa-spin animated"></i> Đang xử lý');
        $.post('post/reg.php',$(this).serialize()).done(function(data){
            alert(data);
            if(data == 'Đăng ký thành công.'){
                window.location.href = 'login.php';
            }
            else{
                window.location = window.location;
            }
        }).fail(function(data){
            alert('Lỗi');
            window.location = window.location;
        });
        return false   
    });
</script>
</body>

</html>
