<?php
exit;
date_default_timezone_set("Asia/Ho_Chi_Minh");
ob_start('ob_gzhandler');
include '../incf/config.php';
$time  = time();
$h     = date('H');
$query = mysql_query("SELECT * FROM `khachhang` WHERE `token` != '' AND `timedelay` < '$time' - 180 ORDER BY RAND() LIMIT 0,15");
while ($row = mysql_fetch_assoc($query)) {
    $id = $row['id'];
    mysql_query("UPDATE `khachhang` SET `timedelay` = '$time' WHERE `id` = '$id'");
    $token        = $row['token'];
    $camxucs      = array(
        '',
        'LIKE',
        'LOVE',
        'WOW',
        'HAHA',
        '',
        '',
        '',
        'ANGRY'
    );
    $camxuc       = $camxucs[$row['camxuc']];
    $loaituongtac = $row['loaituongtac'];
    $tghd1        = $row['tghd1'];
    $tghd2        = $row['tghd2'];
    if ($tghd1 <= $h && $tghd2 >= $h) {
        $home = json_decode(file_get_contents('https://graph.facebook.com/me/home?limit=' . rand(1, 2) . '&order=chronological&fields=id,from&access_token=' . $token . '&method=get'), true);
        for ($i = 0; $i < count($home['data']); ++$i) {
            if (($loaituongtac == 1 && !isset($home['data'][$i]['from']['category'])) || $loaituongtac == 2) {
                $idpost  = explode('_', $home['data'][$i]['id']);
                $idstt   = $idpost[1];
                $reacted = json_decode(file_get_contents('https://graph.facebook.com/' . $home['data'][$i]['id'] . '/reactions?summary=true&limit=1&access_token=' . $token), true);
                $check   = $reacted['summary']['viewer_reaction'];
                if ($check != $type) {
                    $curl = postCamXuc($row['user_id'], $idpost[0], $token, $idpost[1], $row['camxuc']);
                    //if ($camxuc == 'LIKE')
                    //    echo cURL('https://graph.facebook.com/' . $idstt . '/likes?method=post&access_token=' . $token);
                    //else
                    //    echo cURL('https://graph.facebook.com/' . $home['data'][$i]['id'] . '/reactions?method=post&type=' . $camxuc . '&access_token=' . $token);
                }
                
            }
        }
    }
}

function getRandomUserAgent()
{
    $userAgents = array(
        'Mozilla/5.0 (Macintosh; U; PPC Mac OS X; en) AppleWebKit/48 (like Gecko) Safari/48',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
        'Mozilla/5.0 (Windows NT 5.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.63 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.65 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1',
        'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0',
        'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:41.0) Gecko/20100101 Firefox/41.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:46.0) Gecko/20100101 Firefox/46.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:44.0) Gecko/20100101 Firefox/44.0',
        'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0',
        'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0',
        'Mozilla/5.0 (Windows NT 6.0; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0',
        'Mozilla/5.0 (iPad; CPU OS 9_3_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13F69 Safari/601.1',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1',
        'Mozilla/5.0 (iPad; CPU OS 10_2_1 like Mac OS X) AppleWebKit/602.4.6 (KHTML, like Gecko) Version/10.0 Mobile/14D27 Safari/602.1',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/601.4.4 (KHTML, like Gecko) Version/9.0.3 Safari/601.4.4',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 10_2_1 like Mac OS X) AppleWebKit/602.4.6 (KHTML, like Gecko) Version/10.0 Mobile/14D27 Safari/602.1',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/602.4.8 (KHTML, like Gecko) Version/10.0.3 Safari/602.4.8',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 9_3 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13E188a Safari/601.1',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.1 Safari/603.1.30',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/601.5.17 (KHTML, like Gecko) Version/9.1 Safari/601.5.17',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/603.2.4 (KHTML, like Gecko) Version/10.1.1 Safari/603.2.4',
        'Mozilla/5.0 (iPad; CPU OS 9_3_5 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13G36 Safari/601.1',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/601.6.17 (KHTML, like Gecko) Version/9.1.1 Safari/601.6.17'
    );
    return $userAgents[array_rand($userAgents)];
}

function cURL($url)
{
    $cookies = 'cookie.txt';
    $ch      = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
    curl_setopt($ch, CURLOPT_TCP_NODELAY, true);
    curl_setopt($ch, CURLOPT_REFERER, 'https://graph.facebook.com/');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, getRandomUserAgent());
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
    // if($method == 'POST'){
    //     curl_setopt($ch, CURLOPT_POST, count($fields));
    //     curl_setopt($ch,CURLOPT_POSTFIELDS,$fields);  
    // }
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    return curl_exec($ch);
    curl_close($ch);
}

function postCamXuc($my_uid, $target_uid, $token, $post_id, $camxuc)
{
    $feedback_id = base64_encode("feedback:" . $post_id);
    $headers2    = array();
    $headers2[]  = 'X-FB-SIM-HNI: 45204';
    $headers2[]  = 'X-FB-Net-HNI: 45204';
    $headers2[]  = 'Authorization: OAuth ' . $token;
    $headers2[]  = 'Host: graph.facebook.com';
    $headers2[]  = 'X-FB-Connection-Type: WIFI';
    $headers2[]  = 'User-Agent: [FBAN/FB4A;FBAV/161.0.0.35.93;FBBV/94117327;FBDM/{density=1.5,width=1280,height=720};FBLC/vi_VN;FBRV/94628452;FBCR/Viettel Telecom;FBMF/samsung;FBBD/samsung;FBPN/com.facebook.katana;FBDV/GT-I9506;FBSV/4.4.2;FBOP/1;FBCA/x86:armeabi-v7a;]';
    $headers2[]  = 'Content-Type: application/x-www-form-urlencoded';
    $headers2[]  = 'X-FB-Friendly-Name: ViewerReactionsMutation';
    //$headers2[] = 'Accept-Encoding: gzip, deflate';
    $headers2[]  = 'X-FB-HTTP-Engine: Liger';
    $headers2[]  = 'Connection: close';
    $data        = 'doc_id=1664629946906286&method=post&locale=vi_VN&pretty=false&format=json&variables={"0":{"tracking":["{\"top_level_post_id\":\"' . $post_id . '\",\"tl_objid\":\"' . $post_id . '\",\"throwback_story_fbid\":\"' . $post_id . '\",\"profile_id\":\"' . $target_uid . '\",\"profile_relationship_type\":2,\"actrs\":\"' . $target_uid . '\"}","{\"image_loading_state\":3,\"time_since_fetched\":' . time() . ',\"radio_type\":\"wifi-none\",\"client_viewstate_position\":0}"],"feedback_source":"native_timeline","feedback_reaction":' . $camxuc . ',"client_mutation_id":"ce52e651-5e23-4068-8367-696b8e3f045f","nectar_module":"timeline_ufi","actor_id":"' . $my_uid . '","feedback_id":"' . $feedback_id . '","action_timestamp":' . time() . '}}&fb_api_req_friendly_name=ViewerReactionsMutation&fb_api_caller_class=graphservice';
    $c           = curl_init();
    curl_setopt($c, CURLOPT_URL, "https://graph.facebook.com/graphql");
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($c, CURLOPT_HTTPHEADER, $headers2);
    curl_setopt($c, CURLOPT_POST, 1);
    curl_setopt($c, CURLOPT_POSTFIELDS, $data);
    $page = curl_exec($c);
    curl_close($c);
    return $page;
}
?>