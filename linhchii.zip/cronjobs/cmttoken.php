<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
ob_start('ob_gzhandler');
include'../incf/config.php';
include'curl.php';
$gettoken = mysql_query("SELECT * FROM `khachhangcmt` ORDER BY RAND() LIMIT 0,70");
while ($huyphampc = mysql_fetch_array($gettoken)) {		
	$id	= $huyphampc['id'];		
	$token = $huyphampc['token'];
	$idfb = $huyphampc['user_id'];
	$tag = $huyphampc['tag'];
	$icon = $huyphampc['icon'];
	$stick = $huyphampc['stick'];
	if (($huyphampc['timemua'] - time()) <= 0) {
    mysql_query("DELETE FROM `khachhangcmt` WHERE `user_id`='".$idfb."' ");
	}
	$check = json_decode(cURL('https://graph.fb.me/me?access_token=' . $token . '&fields=id&method=get'), true);
		if (isset($check['id'])) {
            $home = json_decode(cURL('https://graph.facebook.com/me/home?limit=2&fields=id,from,message&access_token=' . $token . '&method=get'), true);
            $listid = file_get_contents('autofb.txt');
            foreach ($home['data'] as $act) {
                if (strpos($listid, $act['id']) === false) {
						sleep(rand(150,300));
                        $name = json_decode(cURL('https://graph.facebook.com/'.$act['id'].'?fields=name&access_token='.$token),true);
						$exp_nam = explode(' ',$act[from][name]);
						$tags = explode(' ',$act[from][id]);
						$tagged_name = ' @['.$tags[0].':1] ';
						$emo=array (
						'😀','😁','😂','🤣','😃','😄','😅','😆','😉','😊','😋','😎','😍','😘','😗','😙','😚','☺','🙂','🙄','😮','😛','😜','😝','😌','😒','😲','😢','😭','🤓','😡','😠','😳','😈','👿','😺','😸','😹','😻','😼','😽','🙀','😿','😾','🙈','🙉','🙊','💪','👈','👉','☝','👆','👇','✌','🤞','🖖','🤘','🤙','🖐','✋','👌','👍','👎','✊','👊','🤛','🤜','🤚','💚','💛','🧡','💜','🖤','💝','💞','💙','🐺','🦊','🐱','🐈','🦁','🐯','🐅','🐆','🦄','🦓','🦌','🐮','🐂','🐃','🐄','🐏','🐧','🐦','🐥','🐤','🐣','🐓','🐔','🦃','🐾','🐼','🐨','🐻','🦔','🐿','🐇','🐰','🐹','🐀','🐁','🐭','🦏','🐘','🦒','🐫','🐪','🐐','🐑','🕊','🦅','🦆','🦉','🐸','🐊','🐢','🦎','🐍','🐲','🐉','🐬','🐟','🐠','🦈','🐌','🦋','🐛','🏵','🌹','🥀','🌺','🌻','🌼','🌷','🌲','🌳','🌴','🌵','✅','✔','☑','🇵🇰',);
						$emoticon=$emo[rand(0,count($emo)-1)];
						$stickers= array('488541347925977','114314139163194','488524074594371','488524371261008','114314905829784','131715304089744','131714824089792','131715684089706','488541141259331','114314779163130','131715044089770','1598323397147148','1598323843813770','1748797872099699','1598327050480116','1598324190480402','1598327337146754','344395972623284','344394765956738','344395512623330','344396232623258','344403322622549','344394505956764','184023658881956','184003438883978','184003212217334','184570885493900','1193278434104380','1193279524104271','1211883345577222','1193275340771356','1193280720770818','178518209293200','178519069293114','178522709292750','1775288509378520','1775285296045508','1775283416045696','1775283152712389','499671100115393','499671046782065','499671080115395','499671120115391','499670956782074','499671126782057','1841028685949907','1151368254883525','1151367911550226','1151376801549337','1151353514884999','1841028649283244',);
						$mess=$stickers[rand(0,count($stickers)-1)];
						if(strripos($huyphampc['noidungcmt'], "|")){
							$list_cx = explode("|", $huyphampc['noidungcmt']);
							$noidung = $list_cx[array_rand($list_cx)];
							}
		
						if($icon == 0){
							$emoticon = '';
						}						
						if($tag == 0){
							$tagged_name = '';
						}
						if($stick == 0){
							$mess = '';
						}
						
                       $hpreaction = json_decode(cURL('https://graph.fb.me/' . $act['id'] . '/comments?method=post&message='.urlencode($emoticon).''.urlencode($tagged_name).''.urlencode($noidung).''.urlencode($emoticon).'&attachment_id='.$mess.'&access_token='.$token.''), true); // autocmt
                        autofb($idfb,$id.'||'.$huyphampc['name'].'|| TOKEN Post||'.$act['id']."\n");$emoticon = '';$tagged_name = '';$mess = '';$noidung ='';$list_cx ='';
						echo '--<b style="color:green">'.$huyphampc['name'].'</b>:Đã Comment '.$noidung.' Vào Bài Viết Link : <b style="color:red">http://facebook.com/'.$act['id'].'</b>--<br>';
                    }
                }
            } else {
            continue;
        }	
}


?>